import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DatabaseManager {
    public Connection connect() throws SQLException {
        String url = "jdbc:postgresql://localhost:5432/s3g5";
        String user = "postgres";
        String password = "1234";

        return DriverManager.getConnection(url, user, password);
    }

    public void insertBook(int id, String title, int year, int pages, String author, String genre) {
        String SQL = "INSERT INTO books(id, title, year, pages, author, genre) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = connect();
            PreparedStatement pstmt = conn.prepareStatement(SQL)) {
            pstmt.setInt(1, id);
            pstmt.setString(2, title);
            pstmt.setInt(3, year);
            pstmt.setInt(4, pages);
            pstmt.setString(5, author);
            pstmt.setString(6, genre);
            pstmt.executeUpdate();
            System.out.println("Libro " + title + " inserito correttamente.");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void insertMagazine(int id, String title, int year, int pages) {
        String SQL = "INSERT INTO magazines(id, title, year, pages) VALUES (?, ?, ?, ?)";

        try (Connection conn = connect();
            PreparedStatement pstmt = conn.prepareStatement(SQL)) {
            pstmt.setInt(1, id);
            pstmt.setString(2, title);
            pstmt.setInt(3, year);
            pstmt.setInt(4, pages);
            pstmt.executeUpdate();
            System.out.println("Rivista " + title + " inserito correttamente.");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void insertUser(String name, String lastName, int birth, int id) {
        String SQL = "INSERT INTO users(name, lastName, birth, id) VALUES (?, ?, ?, ?)";

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {
            pstmt.setString(1, name);
            pstmt.setString(2, lastName);
            pstmt.setInt(3, birth);
            pstmt.setInt(4, id);
            pstmt.executeUpdate();
            System.out.println("Utente " + name + " inserito correttamente.");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void getBooks() {
        String SQL = "SELECT * FROM books";

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(SQL);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                int id = rs.getInt("id");
                String title = rs.getString("title");
                int year = rs.getInt("year");
                int pages = rs.getInt("pages");
                int author = rs.getString("author");
                int genre = rs.getString("genre");

                System.out.println("ID: " + id + ", Titolo: " + title + ", Anno: " + year + ", Numero pagine: " + pages + ", Autore: " + author + ", Genere: " + genre);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void getMagazines() {
        String SQL = "SELECT * FROM magazines";

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(SQL);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                int id = rs.getInt("id");
                String title = rs.getString("title");
                int year = rs.getInt("year");
                int pages = rs.getInt("pages");

                System.out.println("ID: " + id + ", Titolo: " + title + ", Anno: " + year + ", Numero pagine: " + pages);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void getUsers() {
        String SQL = "SELECT * FROM users";

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(SQL);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                int name = rs.getInt("name");
                int lastName = rs.getString("lastName");
                int birth = rs.getInt("birth");
                int id = rs.getInt("id");

                System.out.println("Nome: " + name + ", Cognome: " + lastName + ", Anno di nascita: " + birth + ", ID: " + id);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
