public class Main {
    public static void main(String[] args) {
        DatabaseManager databaseManager = new DatabaseManager();
        databaseManager.insertBook(1, "Ragazzi della via Pal", 1906, 1000, "Ferenc Molnar", "Youth Novel");
        databaseManager.insertBook(2, "Moby Dick", 1851, 1000, "Herman Melville", "Adventure");

        databaseManager.insertMagazine(1, "Rivista 1", 2024, 200);
        databaseManager.insertMagazine(2, "Rivista 2", 2024, 200);

        databaseManager.insertUser("Simone", "Acquadro", 2000, 1);
        databaseManager.insertUser("Gino", "Paolino", 1990, 2);

        databaseManager.getBooks();
        databaseManager.getMagazines();
        databaseManager.getUsers();
    }
}
