import java.io.Serializable;

class User implements Serializable {
    private String name;
    private String lastName;
    private String birth;
    private String code;

    public User(String name, String lastName, String birth, String code) {
        this.name = name;
        this.lastName = lastName;
        this.birth = birth;
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public String getLastName() {
        return lastName;
    }

    public String getBirth() {
        return birth;
    }

    public String getCode() {
        return code;
    }
}
